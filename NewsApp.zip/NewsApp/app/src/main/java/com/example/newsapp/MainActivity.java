//Name: Jehan Bhathena
//Andrew ID: jbhathen
package com.example.newsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements FetchNewsTask.NewsTaskCallback {

    private EditText searchEditText;
    private Button searchButton;
    private RecyclerView newsRecyclerView;
    private ProgressBar progressBar;
    private TextView errorTextView;

    private NewsAdapter newsAdapter;
    private List<Article> articleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        newsRecyclerView = findViewById(R.id.newsRecyclerView);
        progressBar = findViewById(R.id.progressBar);
        errorTextView = findViewById(R.id.errorTextView);

        // Set up RecyclerView
        articleList = new ArrayList<>();
        newsAdapter = new NewsAdapter(this, articleList);
        newsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        newsRecyclerView.setAdapter(newsAdapter);

        // Set up search button click listener
        searchButton.setOnClickListener(v -> {
            String topic = searchEditText.getText().toString().trim();
            if (topic.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a topic", Toast.LENGTH_SHORT).show();
                return;
            }

            String deviceModel = Build.MODEL;
            new FetchNewsTask(this, deviceModel).execute(topic);
        });
    }

    @Override
    public void onPreExecute() {
        progressBar.setVisibility(View.VISIBLE);
        errorTextView.setVisibility(View.GONE);
        articleList.clear();
        newsAdapter.notifyDataSetChanged();
    }

    @Override
    public void onTaskComplete(List<Article> articles) {
        progressBar.setVisibility(View.GONE);

        if (articles.isEmpty()) {
            errorTextView.setText("No news found for this topic");
            errorTextView.setVisibility(View.VISIBLE);
        } else {
            articleList.clear();
            articleList.addAll(articles);
            newsAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onError(String error) {
        progressBar.setVisibility(View.GONE);
        errorTextView.setText("Error: " + error);
        errorTextView.setVisibility(View.VISIBLE);
    }
}