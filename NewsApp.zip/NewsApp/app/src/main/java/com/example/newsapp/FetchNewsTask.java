//Name: Jehan Bhathena
//Andrew ID: jbhathen
package com.example.newsapp;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class FetchNewsTask extends AsyncTask<String, Void, List<Article>> {

    private static final String TAG = "FetchNewsTask";
    private final NewsTaskCallback callback;
    private final String deviceModel;
    private Exception exception;

    // Update this URL with your actual GitHub Codespace URL
    private static final String BASE_URL = "https://ideal-pancake-rw5x656xvpqfpjqp.github.dev/";

    public FetchNewsTask(NewsTaskCallback callback, String deviceModel) {
        this.callback = callback;
        this.deviceModel = deviceModel;
    }

    @Override
    protected void onPreExecute() {
        callback.onPreExecute();
    }

    @Override
    protected List<Article> doInBackground(String... params) {
        if (params.length == 0) {
            return null;
        }

        String topic = params[0];
        List<Article> articles = new ArrayList<>();

        try {
            String encodedTopic = URLEncoder.encode(topic, "UTF-8");
            String encodedDeviceModel = URLEncoder.encode(deviceModel, "UTF-8");
            String urlStr = BASE_URL + "?topic=" + encodedTopic + "&deviceModel=" + encodedDeviceModel;

            URL url = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                Gson gson = new Gson();
                Type articleListType = new TypeToken<ArrayList<Article>>(){}.getType();
                articles = gson.fromJson(response.toString(), articleListType);
            } else {
                throw new Exception("Error response: " + responseCode);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching news", e);
            this.exception = e;
            return null;
        }

        return articles;
    }

    @Override
    protected void onPostExecute(List<Article> articles) {
        if (articles != null) {
            callback.onTaskComplete(articles);
        } else {
            callback.onError(exception != null ? exception.getMessage() : "Unknown error occurred");
        }
    }

    public interface NewsTaskCallback {
        void onPreExecute();
        void onTaskComplete(List<Article> articles);
        void onError(String error);
    }
}